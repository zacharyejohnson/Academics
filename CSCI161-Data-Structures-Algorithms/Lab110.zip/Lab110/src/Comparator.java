/**
 *
 * @author Zach Johnson
 * @version 11/16/2021
 */
public interface Comparator<K> {
    
    int compare( K a, K b );
}


