/**
 *
 * @author Zach Johnson
 */
public class TimedOutException extends Exception {

    public TimedOutException(String timeOut) {
    } 
}
    

