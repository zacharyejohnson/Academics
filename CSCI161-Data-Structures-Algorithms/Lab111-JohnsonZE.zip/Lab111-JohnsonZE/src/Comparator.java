/**
 *
 * @author Zach Johnson
 * @version 12/3/2021
 */
public interface Comparator<K> {
    
    int compare( K a, K b );
}


